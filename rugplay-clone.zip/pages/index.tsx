import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function Home() {
  const [coins, setCoins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCoins();
  }, []);

  const fetchCoins = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("coins").select("*");
    if (error) console.error("Error fetching coins:", error);
    else setCoins(data);
    setLoading(false);
  };

  const createCoin = async () => {
    const name = prompt("Enter coin name:");
    if (!name) return;
    const { error } = await supabase.from("coins").insert({ name });
    if (error) console.error("Error creating coin:", error);
    fetchCoins();
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">RugPlay Clone</h1>
      <Button onClick={createCoin} className="mb-4">Create New Coin</Button>
      {loading ? (
        <p>Loading coins...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {coins.map((coin) => (
            <Card key={coin.id}>
              <CardContent>
                <h2 className="text-xl font-semibold">{coin.name}</h2>
                <p>ID: {coin.id}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}